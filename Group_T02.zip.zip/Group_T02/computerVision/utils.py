import numpy as np
import cv2

sobel_x = np.array([[-1,0,1],[-2,0,2],[-1,0,1]])
sobel_y = np.array([[-1,-2,-1],[0,0,0],[1,2,1]])

def to_grayscale(img):
    '''
    Converts img to grayscale image
    '''
    return cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)

def convolution2D(img, kernel, padding, stride):
    '''
    Performs a 2-dimensional convolution of img with kernel
    '''
    x_kernel = kernel.shape[0]
    y_kernel = kernel.shape[1]

    assert(x_kernel % 2 == 1)
    assert(y_kernel % 2 == 1)

    x_img = img.shape[0]
    y_img = img.shape[1]

    x_output = int(((x_img - x_kernel + 2 * padding) / stride) + 1)
    y_output = int(((y_img - y_kernel + 2 * padding) / stride) + 1)

    output_array = np.zeros((x_output, y_output))
    x = 4
    y = 5

    if padding != 0:
        image_padded = np.zeros((int(x_img + 2 * padding), int(y_img + 2 * padding)))
        image_padded[padding:-padding, padding:-padding] = img
    else:
        image_padded = img

    for x in range(output_array.shape[0]):
        for y in range(output_array.shape[1]):
            output_array[x,y] = np.sum(kernel * image_padded[x : x + x_kernel, y : y + y_kernel])

    return output_array

def gaussian_kernel(size, sigma):
    '''
    Created a gaussian kernel of shape size x size with standard deviation sigma.
    '''
    assert size % 2 == 1, "Kernel must have odd dimension"

    kernel = np.fromfunction(lambda x, y: (1 / (2 * np.pi * sigma**2)) * np.exp(-((x - size//2)**2 + (y - size//2)**2) / (2 * sigma**2)), (size, size))
    return kernel

def get_mag(img, smoothing=True):
    '''
    Returns the magintude of the gradient of the image
    '''
    if smoothing:
        g_kernel = gaussian_kernel(3, 2)
        img = convolution2D(img, g_kernel, 1, 1)

    x_grad = convolution2D(img, sobel_x, 1, 1)
    y_grad = convolution2D(img, sobel_y, 1, 1)

    G = np.sqrt(x_grad**2 + y_grad**2)

    return G / G.max() * 255

def get_direction(img, smoothing=True):
    '''
    Returns the direction of the gradient of img
    '''
    if smoothing:
        g_kernel = gaussian_kernel(3, 2)
        image = convolution2D(img, g_kernel, 1, 1)

    I_x = convolution2D(img, sobel_x, 1, 1)
    I_y = convolution2D(img, sobel_y, 1, 1)

    return np.arctan2(I_y, I_x)

def pixel_to_adjacents(i, j, G, theta):
    '''
    Finds adjacent pixels perpendicular to the edge passing through (i,j) in G and
    keeps edge only if it is stronger than its adjacent pixels.
    '''
    if (theta <= np.pi/8) or (theta >= 7*np.pi/8):
        pt1 = G[i, j-1]
        pt2 = G[i, j+1]
    elif (np.pi/8 <= theta <= 3*np.pi/8):
        pt1 = G[i-1, j-1]
        pt2 = G[i+1, j+1]
    elif (3*np.pi/8 <= theta <= 5*np.pi/8):
        pt1 = G[i-1, j]
        pt2 = G[i+1, j]
    elif (5*np.pi/8 <= theta <= 7*np.pi/8):
        pt1 = G[i-1, j+1]
        pt2 = G[i+1, j-1]
    else:
        pt1 = 0
        pt2 = 0
    
    if (G[i,j] >= pt1) and (G[i,j] >= pt2):
        return G[i,j]
    else:
        return 0
    
def get_edges(img):
    '''
    Refines the edges in an image img to make the found edges slimmer
    '''
    img_mag = get_mag(img)
    img_dirn = get_direction(img)

    img_dirn[img_dirn < np.pi] += np.pi

    img_edges = np.zeros(img.shape)

    for i in range(1, len(img_edges)-1):
        for j in range(1, len(img_edges[0])-1):
            theta = img_dirn[i,j]
            img_edges[i,j] = pixel_to_adjacents(i, j, img_mag, theta)
    
    return img_edges

def threshold(img, l_threshold=0.15, h_threshold=0.3):
    '''
    Double thresholds the edges into strong and weak edges
    '''
    high_threshold = h_threshold * img.max()
    low_threshold = l_threshold * high_threshold

    output = np.zeros(img.shape)

    strong = 225
    weak = 100

    output[img > high_threshold] = strong
    output[(img < high_threshold) & (img > low_threshold)] = weak
    
    return strong, weak, output

def hysteresis(img, strong, weak):
    '''
    Keeps only weak edges that are connected to strong edges
    '''
    M, N = img.shape
    output = np.zeros((M,N))
    for i in range(1, M-1):
        for j in range(1, N-1):
            if img[i,j] == weak:
                if (img[i-1,j-1] == strong) or (img[i-1,j] == strong) or (img[i-1,j+1] == strong) or (img[i,j-1] == strong) or (img[i,j+1] == strong) or (img[i+1,j-1] == strong) or (img[i+1,j] == strong) or (img[i+1,j+1] == strong):
                    output[i,j] = strong
                else:
                    output[i,j] = weak
            else:
                output[i,j] = img[i,j]
        
    return output

def apply_hysteresis(old_img, strong, weak):
    new_img = hysteresis(old_img, strong, weak)

    if (old_img != new_img).sum() == 0:
        print((old_img != new_img).sum())
        return new_img
    else:
        # Continue refining until the threshold is met
        while (old_img != new_img).sum() > 0:
            old_img = new_img
            new_img = hysteresis(old_img, strong, weak)        
        new_img[new_img < strong] = 0
        return new_img