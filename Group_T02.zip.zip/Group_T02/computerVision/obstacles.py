import numpy as np
import cv2
from shapely import Polygon
import matplotlib.pyplot as plt
from . import utils

def preprocess_image(image, k_size=21, sigma=4):
    """
    Processed the image by turning it to black and white and blurring it with a Gaussian blur 
    with kernel (k_size, k_size) and sigma value sigma in both x and y directions

    image:      imported image with 3 colour channels
    k_size:     int
    sigma:      int
    """
    grey = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
    blurred_image = cv2.GaussianBlur(grey, (k_size,k_size), sigma)

    return blurred_image

def gaussian_threshold(image, k_size, C, show_threshold=False):
    return cv2.adaptiveThreshold(image,255,cv2.ADAPTIVE_THRESH_GAUSSIAN_C,cv2.THRESH_BINARY_INV,k_size,C)

def get_contours(edges_image, curve_sim=0.01, show_contours=False):
    """
    Get the contours from an image containing the edges of our shapes.

    edges_image: Processed image with the found edges of our obstacles
    curve_sim: int, by what factor our found polygons can differ from our original shapes
    """
    contours, _ = cv2.findContours(edges_image,cv2.RETR_EXTERNAL,cv2.CHAIN_APPROX_NONE)
    contour_shapes = []
    
    for contour in contours:
        if len(contour)>300:
            # For finding the polygons that fit around the contours.
            # Epsilon is for deciding how similar the polygons have to be to the original contours
            epsilon = curve_sim * cv2.arcLength(contour,True)
            shape = cv2.approxPolyDP(contour,epsilon,True)
            contour_shapes.append(shape)

    return contour_shapes

def format_polygon_points(contour_shapes, show_polygons=False):
    """
    Formats the polygon points in a way that works for the global navigation module
    """
    polygons = []
    for i in range(len(contour_shapes)):
        shape_points = []
        for j in range(len(contour_shapes[i])):
            shape_points.append((int(contour_shapes[i][j][0][0]), int(contour_shapes[i][j][0][1])))
        polygons.append(Polygon(shape_points))

    return polygons

def find_obstacles(image_path):
    # Can change this later to read in from the camera I suppose
    image = cv2.imread(image_path)

    processed_image = preprocess_image(image)
    threshold_image = gaussian_threshold(processed_image, k_size=21, C=2)
    contours_list = get_contours(threshold_image, curve_sim=0.01)
    return format_polygon_points(contours_list)
